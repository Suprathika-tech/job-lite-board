package com.boot.jobboard.rest.config;


import com.boot.jobboard.rest.dvo.Job;
import com.boot.jobboard.rest.repo.JobRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class JobDataSeeder implements CommandLineRunner {

    private final JobRepository jobRepository;

    public JobDataSeeder(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    @Override
    public void run(String... args) {
        if (jobRepository.count() == 0) {
            Job job1 = new Job(null, "Frontend Developer", "Microsoft", "Hyderabad",
                    "Develop RESTful APIs and microservices using Spring Boot.",
                    "50,000 - 90,000",
                    Arrays.asList("Java", "Spring Boot", "PostgreSQL"));

            Job job2 = new Job(null, "Backend Developer", "Cognizant", "Chennai",
                    "Build engaging UIs using React.js and Material-UI.",
                    "70,000 - 100,000",
                    Arrays.asList("React", "JavaScript", "CSS"));

            Job job3 = new Job(null, "Full Stack Developer", "capgemini", "Remote",
                    "Work across frontend and backend on a SaaS platform.",
                    "60,000 - 90,000",
                    Arrays.asList("Java", "React", "MySQL", "Spring Boot"));
            Job job4 = new Job(null, "Frontend Developer", "Infosys", "Hyderabad",
                    "Create dynamic user interfaces using modern JavaScript frameworks.",
                    "65,000 - 95,000",
                    Arrays.asList("React", "TypeScript", "HTML", "CSS"));

            Job job5 = new Job(null, "Java Developer", "Wipro", "Pune",
                    "Develop enterprise-level applications with Java and Spring Boot.",
                    "70,000 - 100,000",
                    Arrays.asList("Java", "Spring Boot", "Hibernate", "MySQL"));

            Job job6 = new Job(null, "Software Engineer", "TCS", "Kolkata",
                    "Contribute to development of scalable software systems.",
                    "60,000 - 85,000",
                    Arrays.asList("Java", "React", "SQL", "Git"));

            jobRepository.saveAll(Arrays.asList(job1, job2, job3,job4,job5,job6));

            System.out.println("✅ Sample jobs added to database.");
        }
    }
}
