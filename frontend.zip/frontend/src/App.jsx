// src/App.jsx or src/router/AppRoutes.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import JobDetails from './pages/JobDetails';
import ApplyPage from './pages/ApplyPage';
import Confirmation from './pages/Confirmation';  
import Home from './pages/Home';
function App() {
  return (
    <>
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/jobs/:id" element={<JobDetails />} />
        <Route path="/apply/:id" element={<ApplyPage />} />
      </Routes>
    </Router>
    </>
  );
}

export default App;
