import React from 'react';
import './Navbar.css'; // if you want external styling

const Navbar = ({ searchKeyword, setSearchKeyword, onSearch, navigateHome }) => {
  return (
    <div style={styles.navbar}>
      <img
        src="https://cdn-icons-png.flaticon.com/512/25/25694.png"
        alt="Home"
        style={styles.homeIcon}
        onClick={navigateHome}
      />
      <input
        type="text"
        placeholder="Search job roles..."
        value={searchKeyword}
        onChange={(e) => setSearchKeyword(e.target.value)}
        style={styles.searchInput}
      />
      <button onClick={onSearch} style={styles.searchButton}>
        Search
      </button>
    </div>
  );
};

const styles = {
  navbar: {
    display: 'flex',
    alignItems: 'center',
    padding: '10px 20px',
    backgroundColor: '#f9f9f9',
    borderBottom: '1px solid #ccc',
    gap: '10px',
  },
  homeIcon: {
    width: '30px',
    height: '30px',
    cursor: 'pointer',
  },
  searchInput: {
    flex: 1,
    padding: '6px 10px',
    fontSize: '16px',
  },
  searchButton: {
    padding: '6px 12px',
    fontSize: '16px',
  },
};

export default Navbar;
