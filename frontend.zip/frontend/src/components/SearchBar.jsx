import React from 'react';

const SearchBar = ({ value, onChange, onSearch }) => (
  <div>
    <input
      type="text"
      placeholder="Search job roles..."
      value={value}
      onChange={e => onChange(e.target.value)}
    />
    <button onClick={onSearch}>Search</button>
  </div>
);

export default SearchBar;
