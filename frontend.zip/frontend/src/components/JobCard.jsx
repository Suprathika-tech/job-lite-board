import React from 'react';
import { Link } from 'react-router-dom';
import './JobCard.css';  // import CSS for styling

const JobCard = ({ job }) => {
  return (
    <div className="job-card">
      <h2>{job.title}</h2>
      <p><strong>Company:</strong> {job.company}</p>
      <p><strong>Location:</strong> {job.location}</p>
      <p>{job.description.substring(0, 100)}...</p>
      <Link to={`/jobs/${job.id}`}>
        <button className="view-details-btn">View Details</button>
      </Link>
    </div>
  );
};

export default JobCard;
