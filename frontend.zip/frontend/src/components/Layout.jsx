
import React from 'react';
import Navbar from './Navbar';

const Layout = ({ children, value, onChange, onSearch }) => {
  return (
    <div>
      <Navbar value={value} onChange={onChange} onSearch={onSearch} />
      <div style={{ paddingTop: '80px', display: 'flex', justifyContent: 'center' }}>
        <div style={{ width: '100%', maxWidth: '800px', textAlign: 'center' }}>
          {children}
        </div>
      </div>
    </div>
  );
};

export default Layout;
