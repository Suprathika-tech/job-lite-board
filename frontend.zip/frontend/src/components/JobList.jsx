import React from 'react';
import JobCard from './JobCard';

const JobList = ({ jobs }) => {
  if (!jobs.length) return <p>No jobs found.</p>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      {jobs.map(job => <JobCard key={job.id} job={job} />)}
    </div>
  );
};

export default JobList;
