import axios from 'axios';
const API_BASE = 'http://localhost:8081/api';

export const getAllJobs = () => axios.get(`${API_BASE}/jobs`);
export const searchJobs = (role) => axios.get(`${API_BASE}/jobs/search`, { params: { role } });
export const getJobById = (id) => axios.get(`${API_BASE}/jobs/${id}`);
export const applyToJob = (application) => axios.post(`${API_BASE}/applications`, application);
