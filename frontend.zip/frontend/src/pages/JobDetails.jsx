// src/pages/JobDetails.jsx
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';

const JobDetails = () => {
  const { id } = useParams(); // job ID from route
  const [job, setJob] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:8081/api/jobs/${id}`)
      .then(res => setJob(res.data))
      .catch(err => console.error('Error fetching job:', err));
  }, [id]);

  if (!job) return <p>Loading...</p>;

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <h2>{job.title}</h2>
      <p><strong>Company:</strong> {job.company}</p>
      <p><strong>Location:</strong> {job.location}</p>
      <p><strong>Description:</strong> {job.description}</p>
      <p><strong>Skills:</strong> {job.requiredSkills.join(', ')}</p>
      <p><strong>Salary Range:</strong> {job.salaryRange}</p>

      {/* Button to Apply */}
      <Link to={`/apply/${job.id}`}>
        <button>Apply Now</button>
      </Link>
    </div>
  );
};

export default JobDetails;
