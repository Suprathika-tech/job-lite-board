// src/pages/ApplyPage.jsx
import React from 'react';
import { useParams } from 'react-router-dom';
import ApplyForm from './ApplyForm';

const ApplyPage = () => {
  const { id } = useParams(); // extract jobId from URL

  return (
    <div>
      <ApplyForm jobId={id} />
    </div>
  );
};

export default ApplyPage;


// const ApplyPage = () => {
//   const { id } = useParams();

//   // ✅ Convert id to number before passing to the form
//   const numericJobId = parseInt(id, 10);

//   return (
//     <div>
//       <ApplyForm jobId={numericJobId} />
//     </div>
//   );
// };

// export default ApplyPage;


