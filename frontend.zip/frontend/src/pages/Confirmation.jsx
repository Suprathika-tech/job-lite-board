import React from 'react';

const Confirmation = () => (
  <div style={{ textAlign: 'center' }}>
    <h2>Application Submitted</h2>
    <p>Thank you for applying. We’ll get back to you soon!</p>
  </div>
);

export default Confirmation;
