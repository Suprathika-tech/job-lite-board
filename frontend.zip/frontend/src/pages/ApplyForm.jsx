// src/components/ApplyForm.jsx
import React, { useState } from 'react';
import axios from 'axios';
import './ApplyForm.css';

const ApplyForm = ({ jobId }) => {
  const [form, setForm] = useState({ fullName: '', email: '' });
  const [message, setMessage] = useState('');

  const isValidName = (name) => /^[A-Za-z\s]+$/.test(name);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isValidName(form.fullName)) {
      setMessage("Full name must contain only alphabets.");
      return;
    }

    try {
      await axios.post('http://localhost:8081/api/applications', {
        jobId: jobId,
        fullName: form.fullName,
        email: form.email,
      });

      setMessage("Application submitted successfully!");
      setForm({ fullName: '', email: '' });
    } catch (error) {
      console.error("Submission failed:", error);
      setMessage("Failed to submit application. Please try again.");
    }
  };

  return (
    <div className="apply-form-container">
      <h2>Apply for Job</h2>
      {message && <p className="message">{message}</p>}
      <form onSubmit={handleSubmit} className="apply-form">
        <input
          type="text"
          placeholder="Full Name"
          value={form.fullName}
          required
          onChange={(e) => setForm({ ...form, fullName: e.target.value })}
        />
        <input
          type="email"
          placeholder="Email"
          value={form.email}
          required
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default ApplyForm;



// src/components/ApplyForm.jsx
// import React, { useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom'; // ✅ import useNavigate
// import './ApplyForm.css';

// const ApplyForm = ({ jobId }) => {
//   const [form, setForm] = useState({ fullName: '', email: '' });
//   const [message, setMessage] = useState('');
//   const navigate = useNavigate(); // ✅ initialize navigate

//   const isValidName = (name) => /^[A-Za-z\s]+$/.test(name);

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (!isValidName(form.fullName)) {
//       setMessage("Full name must contain only alphabets.");
//       return;
//     }

//     try {
//       await axios.post('http://localhost:8081/api/applications', {
//         jobId: jobId,
//         fullName: form.fullName,
//         email: form.email,
//       });

//       // ✅ Navigate to confirmation page
//       navigate('/confirmation'); 
//     } catch (error) {
//       console.error("Submission failed:", error);
//       setMessage("Failed to submit application. Please try again.");
//     }
//   };

//   return (
//     <div className="apply-form-container">
//       <h2>Apply for Job</h2>
//       {message && <p className="message">{message}</p>}
//       <form onSubmit={handleSubmit} className="apply-form">
//         <input
//           type="text"
//           placeholder="Full Name"
//           value={form.fullName}
//           required
//           onChange={(e) => setForm({ ...form, fullName: e.target.value })}
//         />
//         <input
//           type="email"
//           placeholder="Email"
//           value={form.email}
//           required
//           onChange={(e) => setForm({ ...form, email: e.target.value })}
//         />
//         <button type="submit">Submit</button>
//       </form>
//     </div>
//   );
// };

// export default ApplyForm;
