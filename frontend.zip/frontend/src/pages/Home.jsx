import React, { useEffect, useState } from 'react';
import JobList from '../components/JobList';
import axios from 'axios';

const Home = ({ jobs, setJobs, searchKeyword }) => {
  // { jobs, setJobs, searchKeyword }
  // const [jobs ,setJobs]=useState([]);
  // const [searchKeyword ,setSearchKeyword]=useState('');
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const endpoint = searchKeyword
          ? `http://localhost:8081/api/jobs/search?role=${searchKeyword}`
          : 'http://localhost:8081/api/jobs';
        const res = await axios.get(endpoint);
        setJobs(res.data);
      } catch (err) {
        console.error(err);
        setJobs([]);
      }
    };

    fetchJobs();
  }, [searchKeyword, setJobs]);

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <h1>Welcome to Job Board Lite</h1>
      <JobList jobs={jobs} />
    </div>
  );
};

export default Home;
